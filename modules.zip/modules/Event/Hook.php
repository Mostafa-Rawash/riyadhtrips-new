<?php


namespace Modules\Event;


class Hook
{
    const FORM_AFTER_TERM_EDIT_UPLOAD_IMAGE = 'event_term_form_after_upload_image';

    const AFTER_SAVING = 'tour_after_saving';
}
