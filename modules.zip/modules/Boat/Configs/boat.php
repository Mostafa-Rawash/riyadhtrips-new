<?php
return [
    'layouts'=>[
        'normal'=>__("Normal Layout"),
        'map'=>__("Map Layout"),
    ]
];
